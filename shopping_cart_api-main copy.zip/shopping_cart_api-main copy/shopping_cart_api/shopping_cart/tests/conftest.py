import pytest


@pytest.fixture
def phone_number():
    return '+18659789244'
